#!/bin/bash
#$ -N chromEvol_Acer
#$ -S /bin/bash
#$ -cwd
#$ -e /groups/itay_mayrose/liorglic/mating_system/PPMS/automatic_pipeline/pipeline_no_missing_traits//Thalictrum//Thalictrum_dimorphism_Independent_ML.sh_ER
#$ -o /groups/itay_mayrose/liorglic/mating_system/PPMS/automatic_pipeline/pipeline_no_missing_traits//Thalictrum//Thalictrum_dimorphism_Independent_ML.sh_OU
/groups/itay_mayrose/liorglic/mating_system/PPMS/Analysis/BayesTraitsV2 /groups/itay_mayrose/liorglic/mating_system/PPMS/automatic_pipeline/pipeline_no_missing_traits//Thalictrum/Thalictrum.nex /groups/itay_mayrose/liorglic/mating_system/PPMS/automatic_pipeline/pipeline_no_missing_traits//Thalictrum//Thalictrum_dimorphism_Independent_ML_traits < /groups/itay_mayrose/liorglic/mating_system/PPMS/automatic_pipeline/pipeline_no_missing_traits//Thalictrum/commands_ML_ind
