#!/bin/bash
#$ -N chromEvol_Acer
#$ -S /bin/bash
#$ -cwd
#$ -e /groups/itay_mayrose/liorglic/mating_system/PPMS/automatic_pipeline/pipeline_no_missing_traits//Lycium//Lycium_dioecy_Dependent_ML.sh_ER
#$ -o /groups/itay_mayrose/liorglic/mating_system/PPMS/automatic_pipeline/pipeline_no_missing_traits//Lycium//Lycium_dioecy_Dependent_ML.sh_OU
/groups/itay_mayrose/liorglic/mating_system/PPMS/Analysis/BayesTraitsV2 /groups/itay_mayrose/liorglic/mating_system/PPMS/automatic_pipeline/pipeline_no_missing_traits//Lycium/Lycium.nex /groups/itay_mayrose/liorglic/mating_system/PPMS/automatic_pipeline/pipeline_no_missing_traits//Lycium//Lycium_dioecy_Dependent_ML_traits < /groups/itay_mayrose/liorglic/mating_system/PPMS/automatic_pipeline/pipeline_no_missing_traits//Lycium/commands_ML_dep
